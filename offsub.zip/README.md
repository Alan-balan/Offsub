# Offline Subtitles 0.3 — sherpa-onnx streaming ASR

В этой версии Whisper удалён.

Стек:
AudioPlaybackCapture → AudioRecord 16 kHz → sherpa-onnx OnlineRecognizer → streaming Zipformer INT8 → ML Kit Translation → overlay.

ASR-модели:
- English Zipformer 20M INT8 — около 44 MB;
- Russian small Zipformer INT8 — около 30 MB.

Модели скачиваются отдельными файлами с Hugging Face и сохраняются в private app storage.
После скачивания ASR работает без сети.

Почему streaming:
sherpa-onnx принимает float PCM чанками и умеет incremental decoding/endpointing, поэтому для субтитров не нужно ждать окончания 2–5 секундного WAV-фрагмента.

Сборка:
./gradlew assembleDebug

Официальный Android/Maven artefact:
com.github.k2-fsa:sherpa-onnx:v1.13.4

Ограничение:
приложение-источник может запретить AudioPlaybackCapture. Это ограничение Android.

Примечание:
текущая модель перевода в CaptureService — EN→RU. UI уже содержит выбор целевого языка; следующий этап — связать все выбранные пары ML Kit и добавить автоопределение source language.
