package com.example.offlinesubtitles

import android.app.*
import android.content.*
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import com.k2fsa.sherpa.onnx.*
import java.io.File
import kotlin.math.abs

class CaptureService : Service() {
    companion object {
        const val START = "START"
        const val RESULT_CODE = "resultCode"
        const val RESULT_DATA = "resultData"
        const val MODEL_ID = "modelId"
        private const val CHANNEL = "offline_subtitles"
    }

    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    private var recognizer: OnlineRecognizer? = null
    private var stream: OnlineStream? = null
    private var overlay: TextView? = null
    private var running = false
    private var lastText = ""

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == START) {
            notification()
            startCapture(i)
        }
        return START_NOT_STICKY
    }

    private fun notification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL, "Offline subtitles", NotificationManager.IMPORTANCE_LOW))
        startForeground(10, Notification.Builder(this, CHANNEL)
            .setContentTitle("Offline Subtitles")
            .setContentText("Streaming ASR работает локально")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
    }

    private fun startCapture(i: Intent) {
        val modelId = i.getStringExtra(MODEL_ID) ?: return
        val model = ModelCatalog.models.firstOrNull { it.id == modelId } ?: return
        val dir = ModelManager(this).dir(model)

        val cfg = OnlineRecognizerConfig(
            modelConfig = OnlineModelConfig(
                transducer = OnlineTransducerModelConfig(
                    encoder = File(dir, "encoder.int8.onnx").absolutePath,
                    decoder = File(dir, "decoder.onnx").absolutePath,
                    joiner = File(dir, "joiner.int8.onnx").absolutePath
                ),
                tokens = File(dir, "tokens.txt").absolutePath,
                modelType = "zipformer2",
                numThreads = maxOf(1, Runtime.getRuntime().availableProcessors() / 2),
                provider = "cpu"
            ),
            enableEndpoint = true,
            decodingMethod = "greedy_search"
        )
        recognizer = OnlineRecognizer(config = cfg)
        stream = recognizer!!.createStream()

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val data = i.getParcelableExtra<Intent>(RESULT_DATA) ?: return
        projection = mgr.getMediaProjection(i.getIntExtra(RESULT_CODE, -1), data)

        val capture = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(16000)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()

        val min = AudioRecord.getMinBufferSize(
            16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)

        recorder = AudioRecord.Builder().setAudioFormat(format)
            .setBufferSizeInBytes(min * 8)
            .setAudioPlaybackCaptureConfig(capture).build()

        showOverlay()
        recorder!!.startRecording()
        running = true
        Thread { audioLoop() }.start()
    }

    private fun audioLoop() {
        val pcm = ShortArray(3200) // 200 ms
        val f = FloatArray(3200)

        while (running) {
            val n = recorder?.read(pcm, 0, pcm.size) ?: -1
            if (n <= 0) continue
            var energy = 0.0
            for (x in 0 until n) {
                val v = pcm[x].toFloat() / 32768f
                f[x] = v
                energy += abs(v)
            }
            // Streaming recognizer gets every chunk; very low-energy chunks are skipped.
            if (energy / n < 0.002) continue

            val s = stream ?: continue
            s.acceptWaveform(16000, f.copyOf(n))
            while (recognizer!!.isReady(s)) recognizer!!.decode(s)

            val text = recognizer!!.getResult(s).text.trim()
            if (text.isNotEmpty() && text != lastText) {
                lastText = text
                updateOverlay(text)
            }

            if (recognizer!!.isEndpoint(s)) {
                if (lastText.isNotEmpty()) {
                    translate(lastText)
                }
                recognizer!!.reset(s)
                lastText = ""
            }
        }
    }

    private fun translate(text: String) {
        // MVP: EN→RU. Target selector is the next step for all supported ML Kit pairs.
        val opts = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.RUSSIAN).build()
        val t = Translation.getClient(opts)
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                t.translate(text).addOnSuccessListener { tr ->
                    updateOverlay("$text\n$tr")
                    t.close()
                }.addOnFailureListener { t.close() }
            }.addOnFailureListener { t.close() }
    }

    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "Слушаю…"; textSize = 20f
            setPadding(24, 14, 24, 14)
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC000000.toInt())
        }
        wm.addView(overlay, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.BOTTOM; y = 100
            })
    }

    private fun updateOverlay(s: String) {
        Handler(Looper.getMainLooper()).post { overlay?.text = s }
    }

    override fun onDestroy() {
        running = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        stream?.release()
        recognizer?.release()
        projection?.stop()
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
