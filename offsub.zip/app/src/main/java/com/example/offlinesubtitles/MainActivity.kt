package com.example.offlinesubtitles

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*

class MainActivity : AppCompatActivity() {
    private lateinit var manager: ModelManager

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK && r.data != null) {
                val model = ModelCatalog.models[findViewById<Spinner>(R.id.modelSpinner).selectedItemPosition]
                if (!manager.isInstalled(model)) {
                    status("Сначала скачайте ASR-модель")
                    return@registerForActivityResult
                }
                startForegroundService(Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.START
                    putExtra(CaptureService.RESULT_CODE, r.resultCode)
                    putExtra(CaptureService.RESULT_DATA, r.data)
                    putExtra(CaptureService.MODEL_ID, model.id)
                })
                status("Слушаю системный звук")
            }
        }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        manager = ModelManager(this)

        val labels = ModelCatalog.models.map {
            it.title + if (manager.isInstalled(it)) " ✓" else ""
        }
        findViewById<Spinner>(R.id.modelSpinner).adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

        findViewById<Spinner>(R.id.targetSpinner).adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Русский", "English", "Deutsch"))

        findViewById<Button>(R.id.downloadButton).setOnClickListener {
            val m = ModelCatalog.models[findViewById<Spinner>(R.id.modelSpinner).selectedItemPosition]
            Thread {
                try {
                    manager.download(m) { s -> runOnUiThread { status(s) } }
                    runOnUiThread { status("Модель ${m.title} готова офлайн") }
                } catch (e: Exception) {
                    runOnUiThread { status("Ошибка: ${e.message}") }
                }
            }.start()
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
                return@setOnClickListener
            }
            val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projectionLauncher.launch(pm.createScreenCaptureIntent())
        }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            status("Остановлено")
        }
    }

    private fun downloadTranslation() {
        val o = TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.RUSSIAN).build()
        val t = Translation.getClient(o)
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { status("EN→RU модель готова"); t.close() }
            .addOnFailureListener { status("Ошибка перевода: ${it.message}"); t.close() }
    }

    private fun status(s: String) { findViewById<TextView>(R.id.status).text = s }
}
