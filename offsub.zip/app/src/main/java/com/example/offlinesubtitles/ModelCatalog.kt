package com.example.offlinesubtitles

data class AsrModel(
    val id: String,
    val title: String,
    val language: String,
    val sizeMb: Int,
    val files: Map<String, String>
)

object ModelCatalog {
    private const val HF = "https://huggingface.co"

    val models = listOf(
        AsrModel(
            "en20m", "English Zipformer 20M INT8 (~44 MB)", "en", 44,
            mapOf(
                "encoder.int8.onnx" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17/resolve/main/encoder-epoch-99-avg-1.int8.onnx?download=true",
                "decoder.onnx" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17/resolve/main/decoder-epoch-99-avg-1.onnx?download=true",
                "joiner.int8.onnx" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17/resolve/main/joiner-epoch-99-avg-1.int8.onnx?download=true",
                "tokens.txt" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17/resolve/main/tokens.txt?download=true"
            )
        ),
        AsrModel(
            "ruSmall", "Русский Zipformer Small INT8 (~30 MB)", "ru", 30,
            mapOf(
                "encoder.int8.onnx" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-small-ru-vosk-int8-2025-08-16/resolve/main/encoder.int8.onnx?download=true",
                "decoder.onnx" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-small-ru-vosk-int8-2025-08-16/resolve/main/decoder.onnx?download=true",
                "joiner.int8.onnx" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-small-ru-vosk-int8-2025-08-16/resolve/main/joiner.int8.onnx?download=true",
                "tokens.txt" to "$HF/csukuangfj/sherpa-onnx-streaming-zipformer-small-ru-vosk-int8-2025-08-16/resolve/main/tokens.txt?download=true"
            )
        )
    )
}
