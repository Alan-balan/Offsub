package com.example.offlinesubtitles

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class ModelManager(private val context: Context) {
    private val root = File(context.filesDir, "asr-models").apply { mkdirs() }

    fun dir(model: AsrModel) = File(root, model.id)

    fun isInstalled(model: AsrModel): Boolean =
        model.files.keys.all { File(dir(model), it).length() > 0 }

    fun download(model: AsrModel, onProgress: (String) -> Unit) {
        val d = dir(model).apply { mkdirs() }
        for ((name, url) in model.files) {
            val out = File(d, name)
            if (out.exists() && out.length() > 0) continue
            onProgress("Скачивание $name…")
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 30_000
            c.readTimeout = 120_000
            c.instanceFollowRedirects = true
            c.connect()
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
            c.inputStream.use { input ->
                out.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
            }
            c.disconnect()
        }
    }

    fun delete(model: AsrModel) { dir(model).deleteRecursively() }
}
